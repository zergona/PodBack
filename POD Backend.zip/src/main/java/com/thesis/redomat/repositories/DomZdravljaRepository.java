package com.thesis.redomat.repositories;

import com.thesis.redomat.data.models.DomZdravlja;
import org.springframework.data.repository.CrudRepository;

public interface DomZdravljaRepository extends CrudRepository<DomZdravlja, Integer> {
}
