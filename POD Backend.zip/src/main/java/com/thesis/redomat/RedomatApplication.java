package com.thesis.redomat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedomatApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedomatApplication.class, args);
	}

}
