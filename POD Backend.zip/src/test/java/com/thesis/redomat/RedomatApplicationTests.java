package com.thesis.redomat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedomatApplicationTests {

	@Test
	void contextLoads() {
	}

}
